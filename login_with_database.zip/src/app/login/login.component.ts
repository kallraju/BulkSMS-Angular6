import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {LoginService} from '../login.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
      logindata:any;
      signupForm: FormGroup;
      name:any;
      password:any;
    constructor(private fb:FormBuilder,private loginservice:LoginService) { 
        this.signupForm=fb.group({
          'name':[null,Validators.required],
          'psw':[null,Validators.required]
        })
      }

      ngOnInit() { }

      onSubmit(post){
          console.log(post);
          this.name=post.name;
          this.password=post.psw;
          //alert(this.password); 
          this.loginservice.login(post).subscribe(data=>{this.logindata=data}); 
      }
  

}
