import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { Observable } from 'rxjs';
import { map} from 'rxjs/operators';
import { catchError } from 'rxjs/internal/operators/catchError';
import { throwError } from 'rxjs/internal/observable/throwError';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }


  public login(obj):any {
    //console.log(obj);
    return this.http.post('http://localhost:3000/login',obj)
      .pipe(
        map(res =>console.log(res)),
        catchError (err => {
          return throwError("Somthing wrong")
        })
      )
 }

 

}
